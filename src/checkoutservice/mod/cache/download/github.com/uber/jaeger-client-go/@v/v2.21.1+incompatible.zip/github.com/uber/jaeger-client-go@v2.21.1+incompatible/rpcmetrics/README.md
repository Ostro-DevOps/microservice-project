An Observer that can be used to emit RPC metrics
================================================

It can be attached to the tracer during tracer construction.
See `ExampleObserver` function in [observer_test.go](./observer_test.go).
